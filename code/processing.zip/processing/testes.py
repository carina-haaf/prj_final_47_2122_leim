
from processing.videoProcessing import *
from processing.processCsvFile import *
from signal_analysis import *


# create a file to write the features info
features_file = CsvFile("processing/features_file.csv", "w")
file_rows=list()

#audio_path = "../audios/mix_ball_shots_wnoiseReal.wav"
audio_path = "../audios/mix_ball_2.wav"

# get all audio samples
data, sr = sf.read(audio_path)

# get onset feature
onset_feature = librosa.onset.onset_detect( y=data, sr=22050, onset_envelope=None, hop_length=1024, backtrack=True, energy=None, units='frames')
rms_feature = librosa.feature.rms(y=data, hop_length=1024)[0]

# plot the audio and the onsets (vlines)
duration = len(data)/sr # time duratio\n(seconds)
time = np.arange(0, duration, 1/sr) # time array (spaced in 1/sr intervals)

"""

width = [0.4]
for i in range(len(onset_feature)):
    sample = onset_feature[i] * 1024
    current_sec = sample/sr
    plt.vlines(current_sec, 0, 1, linestyles="solid", linewidth=width, colors="r")
    plt.xlim(0, duration)
    plt.ylim(0, 1)
    
    
    
    
    print(len(rms_feature))

    duration_rms = len(rms_feature)/sr # time duratio\n(seconds)
    time_rms = np.arange(0, duration_rms, 1/sr) # time array (spaced in 1/sr intervals)
    
    #plot_signal(time, data, "Time[s]", "Amplitude", "Audio Signal: " + audio_path)
    plot_signal(time_rms, rms_feature, "Time[s]", "Amplitude", "RMS: " + audio_path)
    plt.legend(["audio", "onsets"], loc="upper right")
    print("Plotting the graph...")
    plt.show()

    
"""



