import numpy as np
import os


class Video():

    def __init__(self, file_name):
        self.rel_path = "audios/" + file_name
        self.abs_path = self.get_abs_path()

    def get_rel_path(self):
        return self.rel_path

    def get_abs_path(self):
        return os.path.abspath("../" + self.rel_path)

    def get_file(self):
        return ""
