
from processing.videoProcessing import *
from processing.processCsvFile import *
import os
import numpy as np
import librosa
import soundfile as sf
"""
PASSOS:

- criar uma função para ler as observações etiquetadas do ficheiro CSV (criado
  a partir das etiquetações dos áudios) - CHECK
- percorrer todos os vídeos e transformá-los em audios
- para cada áudio, fazer o "load" para obter todas as amostras
- percorrer essa data e fazer o ciclo "for" do seccionamento/ indexação
- na janela selecionada calcular o RMS, ONSET e SPECTRAL FLUX
- verificar se dentro desta janela existe alguma amostra etiquetada como batida
  de bola (do ficheiro csv obtido a partir do Excel)

"""

def convert_array_to_string(arr):
    string = ""
    for i in range(len(arr)):
        string += str(arr[i]) + ";"

    return string



def get_range_label(ini_idx, final_idx, video_number):
    # read the .csv file
    file = CsvFile("labeling/labeling_" + str(video_number) + ".csv", "r")

    # select intended columns from the file
    columns = file.get_columns(np.array([0, 3]))

    # iterate over the array and verify if its a ball hit
    for i in range(len(columns)):
        column = columns[i]
        first_sample = int(column[2])
        last_sample = int(column[3])

        condition_1 = column[0] == "racket"
        condition_2 = ini_idx >= first_sample and ini_idx <= last_sample
        condition_3 = final_idx >= first_sample and final_idx <= last_sample

        if condition_1 and (condition_2 or condition_3):
            return True
    return False


def organize_feature_values(f1, f2, f3, is_ball_hit, number_of_groups, nr_of_features):
    size = (number_of_groups*nr_of_features) + 1
    organized_arr = [None] * size
    idx = 0
    for i in range(number_of_groups):
        organized_arr[idx] = f1[i]
        idx +=1
        organized_arr[idx] = f2[i]
        idx +=1
        organized_arr[idx] = f3[i]
        idx +=1

    organized_arr[idx] = 1*is_ball_hit
    idx +=1

    return organized_arr


def generate_onset_array(arr, number_of_groups):
    onset_array = np.zeros(number_of_groups + 1)
    onset_array[arr] = 1

    return onset_array


def construct_3row_header_format(file, nr_of_features, nr_groups):
    nr_of_columns = nr_groups * nr_of_features +1

    #construct 1st header (f1, f2, f3, f4, f5, ...)
    idx_arr = np.arange(stop=nr_of_columns, dtype="int")
    idx_str_arr = np.array(idx_arr, dtype="str")
    f_str_arr = np.full(nr_of_columns, "f", dtype="str")
    first_header = np.char.add(f_str_arr, idx_str_arr)


    #construct 2nd header (d, c, d, d, d, c, c, ...)
    str_arr = np.empty(shape=nr_of_columns, dtype="str")
    str_arr[str_arr == ""] = "c"
    str_arr[-1] = "d"
    second_header = str_arr

    #construct 3rd header (, , , , ..., class)
    str_arr = list(np.empty(shape=nr_of_columns, dtype="str"))
    str_arr[-1] = "class"
    third_header = np.array(str_arr)

    file.write_one_line_on_file(first_header)
    file.write_one_line_on_file(second_header)
    file.write_one_line_on_file(third_header)

    return file


def get_data_features(data, vd_idx, number_of_groups, samples_per_group, nr_of_features, nr_samples_slid):

    for i in range(0, len(data)):
        if i * nr_samples_slid + (number_of_groups*samples_per_group) -1 < len(data):
            mini_data = data[i * nr_samples_slid: i * nr_samples_slid + (number_of_groups*samples_per_group)]

            # verify if this range of samples is a hit on the ball
            ini_idx = i * samples_per_group
            final_idx = i * samples_per_group + (number_of_groups*samples_per_group)
            is_ball_hit = get_range_label(ini_idx, final_idx, vd_idx)

            # calculate features
            onset_feature = librosa.onset.onset_detect(y=mini_data, sr=44100, hop_length=1024)
            onset_feature= onset_feature
            onset_feature = generate_onset_array(onset_feature, number_of_groups) # sets onsets indexes to 1 (where occured onset)

            rms_feature = librosa.feature.rms(y=mini_data, hop_length=1024)[0]
            rms_feature = rms_feature

            specflux_feature = librosa.onset.onset_strength(y=mini_data, sr=44100, hop_length=1024)
            specflux_feature = specflux_feature

            # organize feature in an array
            feature_arr = organize_feature_values(onset_feature, rms_feature, specflux_feature, is_ball_hit, number_of_groups, nr_of_features)
            # keep the features data on array
            file_rows.append(feature_arr)


# ================================================================

#                        TESTES

# ================================================================

# hiper-parameters
nog = 20  # number of groups
spr = 1024  # samples per group
nof = 3  # number of features
noss = 1024 # number of slided samples


# create a file to write the features info
features_file = CsvFile("processing/features_file.csv", "w")
features_file.clear_file()
features_file = construct_3row_header_format(file=features_file,
                                             nr_of_features=nof,
                                             nr_groups=nog)
file_rows=list()


# clean audio directory
dir = '../audios'
for f in os.listdir(dir):
    os.remove(os.path.join(dir, f))


# get all videos...
files = np.array(list(os.listdir("../videos")))
for i in range(len(files)):
    v = Video(files[i])
    video = v.get_file()
    print("Path: ", v.get_abs_path())

    # get corresponding audio
    vd_idx = int(files[i].split(".")[0].split("_")[1][0:])
    audio_path = "../audios/AUDIO_" + str(vd_idx) + ".wav"
    video.audio.write_audiofile(audio_path, fps=44100)

    # get all audio samples
    y, sr = sf.read(audio_path)
    y = y[:,0]
    print("shape video" + str(vd_idx) + ": ", y.shape)

    # get audio relevant events
    print("Processing data...")
    get_data_features(y, vd_idx, nog, spr, nof, noss)

    # in the end, write on the file
    features_file.write_lines_on_file(file_rows)

print("The program finnished successfully. Processed files: ", files)





