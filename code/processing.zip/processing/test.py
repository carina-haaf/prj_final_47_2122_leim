import librosa
import numpy as np
import librosa.display
import soundfile as sf


audio_path = "../audios/mix_ball_2.wav"

# get all audio samples...
data, sr = sf.read(audio_path)

o_env = librosa.onset.onset_strength(y=data, sr=sr)
times = librosa.times_like(o_env, sr=sr)
onset_frames = librosa.onset.onset_detect(onset_envelope=o_env, sr=sr)

# plot the graphs...
import matplotlib.pyplot as plt
D = np.abs(librosa.stft(data))
fig, ax = plt.subplots(nrows=2, sharex=True)
librosa.display.specshow(librosa.amplitude_to_db(D, ref=np.max),
                         x_axis='time', y_axis='log', ax=ax[0])
ax[0].set(title='Power spectrogram')
ax[0].label_outer()
ax[1].plot(times, o_env, label='spectral flux')
ax[1].vlines(times[onset_frames], 0, o_env.max(), color='r', alpha=0.9,
           linestyle='--', label='onsets')
ax[1].legend()
plt.show()


